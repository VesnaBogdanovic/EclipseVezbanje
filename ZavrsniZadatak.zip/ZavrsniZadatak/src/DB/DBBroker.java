/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import domain.User;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ja
 */
public class DBBroker {
    Connection connection;
    public void loadDriver(){
        try {
            Class.forName("com.mySQL.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void openConnection(){
        String url = ("jdbc:mySQL://localhost:3306/zavrsnisql");
        String username = "root";
        String password = "volim8.medu";
        try {
            connection = (Connection) DriverManager.getConnection(url, username, password);
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
}
public void closeConnection(){
        try {
            connection.close();
        } catch (SQLException ex) {
            Logger.getLogger(DBBroker.class.getName()).log(Level.SEVERE, null, ex);
        }
    
}

    public void addUser(User user) throws SQLException {
        
       String sqlQuery = "INSERT INTO user VALUES(?,?,?,?)";
        PreparedStatement ps = connection.prepareStatement(sqlQuery);
        
        ps.setString(1, user.getFirstName());
        ps.setString(2, user.getLastName());
        ps.setString(3, user.getEmailAddress());
        ps.setDate(4, new Date (user.getBirthDate().getTime()));
        ps.execute();
        ps.close();
        
        
    }


}
