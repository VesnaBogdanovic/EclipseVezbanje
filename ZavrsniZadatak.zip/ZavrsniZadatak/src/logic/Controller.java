/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logic;

import DB.DBBroker;
import domain.User;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ja
 */
public class Controller {
    DBBroker db;
    private static Controller instance;
    private Controller(){
        db = new DBBroker();
    }
    public static Controller getInstance(){
    if(instance == null)
        instance = new Controller();
    return instance;
        
}

    public void addUser(User user) {
        db.loadDriver();
        db.openConnection();
        try {
            db.addUser(user);
        } catch (SQLException ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
        db.closeConnection();
        
        
    }
}